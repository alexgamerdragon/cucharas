# Como el jugador que usa la Cuchara, en su posición
execute if entity @a[gamemode=spectator] run function cucharas:revivir_ok
execute unless entity @a[gamemode=spectator] run tellraw @s {"text":"No hay ningún jugador caído que revivir.","color":"red"}
