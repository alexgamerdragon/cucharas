# Cada tick: quien haya usado un palo con zanahoria pasa a comprobarse
execute as @a[scores={cuchara_usada=1..}] at @s run function cucharas:usar
