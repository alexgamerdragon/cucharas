# Revive al jugador caído (en espectador) más cercano y gasta una Cuchara
tag @a[gamemode=spectator,limit=1,sort=nearest] add cuchara_revivido

tp @a[tag=cuchara_revivido] @s
gamemode survival @a[tag=cuchara_revivido]
effect give @a[tag=cuchara_revivido] minecraft:resistance 5 4 true

tellraw @a [{"selector":"@a[tag=cuchara_revivido]","color":"green"},{"text":" ha sido revivido con una Cuchara por ","color":"yellow"},{"selector":"@s","color":"green"}]
playsound minecraft:item.totem.use player @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 40

clear @s minecraft:carrot_on_a_stick{cuchara:1b} 1
tag @a remove cuchara_revivido
