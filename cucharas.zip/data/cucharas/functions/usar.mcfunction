# Se ejecuta como el jugador que ha usado el objeto, en su posición
scoreboard players set @s cuchara_usada 0

# Solo cuenta si lleva una Cuchara en la mano principal o en la secundaria
execute if entity @s[nbt={SelectedItem:{tag:{cuchara:1b}}}] run function cucharas:revivir
execute unless entity @s[nbt={SelectedItem:{tag:{cuchara:1b}}}] if entity @s[nbt={Inventory:[{Slot:-106b,tag:{cuchara:1b}}]}] run function cucharas:revivir
