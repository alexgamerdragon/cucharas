# Te da una Cuchara: /function cucharas:dar
give @s minecraft:carrot_on_a_stick{cuchara:1b,CustomModelData:1,Unbreakable:1b,display:{Name:'{"text":"Cuchara","italic":false,"color":"gold"}',Lore:['{"text":"Revive a un jugador caído","italic":false,"color":"gray"}']}} 1
