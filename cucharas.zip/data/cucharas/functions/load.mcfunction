# Se ejecuta al cargar el datapack o hacer /reload
scoreboard objectives add cuchara_usada minecraft.used:minecraft.carrot_on_a_stick
